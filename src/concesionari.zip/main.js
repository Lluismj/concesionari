'use stric'

import Vehicle from "./model/Vehicle.class.js"
import CotxeElectric from "./model/CotxeElectric.class.js"
import {
  vehiclesOrdenatsPerMarca,
  vehiclesOrdenatsPerPreu,
  vehiclesAmbPoquesUnitats,
  valorTotalConcessionari,
  llistaVehicles
} from "./functions/vehicles.functions.js"


document.querySelector('#app').innerHTML = `

`

const vehicle1 = new Vehicle(  'Toyota', 'Corolla',4,23500)
const vehicle2 = new Vehicle('Seat','Ibiza',5,19000)
const vehicle3 = new Vehicle('Ford','Focus',2,27000)
const vehicle4 = new CotxeElectric('Tesla','Model 3',3,39990,513)
const vehicle5 = new CotxeElectric('Hyundai','Ioniq 5',2,45000,507)

const vehicles = [
  vehicle1,
  vehicle2,
  vehicle3,
  vehicle4,
  vehicle5
]



// ----------------------------------------------------
// 2. PROVAR ELS OBJECTES
// ----------------------------------------------------

console.log(vehicle1)
console.log(vehicle4)


// ----------------------------------------------------
// 3. PROVAR valorStock()
// ----------------------------------------------------

console.log('Valor stock Toyota:')
console.log(vehicle1.valorStock())

console.log('Valor stock Tesla:')
console.log(vehicle4.valorStock())


// ----------------------------------------------------
// 4. PROVAR getPrecio()
// ----------------------------------------------------

console.log('Preu Toyota:')
console.log(vehicle1.getPrecio())


// ----------------------------------------------------
// 5. PROVAR canviarPreu()
// ----------------------------------------------------

console.log('Canviem el preu del Toyota:')

vehicle1.canviarPreu(25000)

console.log(vehicle1.getPrecio())
console.log(vehicle1.valorStock())


// ----------------------------------------------------
// 6. PROVAR STATIC
// ----------------------------------------------------

console.log('IVA de 10000 €:')
console.log(Vehicle.calcularIVA(10000))

//toString

console.log('Vehicle normal:')
console.log(vehicle1.toString())

console.log('Cotxe elèctric:')
console.log(vehicle4.toString())

//valueOf

console.log('Comparació del valor de stock:')

console.log(vehicle1 > vehicle2)

if (vehicle1 > vehicle2) {
  console.log(`${vehicle1.marca} ${vehicle1.modelo} té més valor en stock`)
} else {
  console.log(`${vehicle2.marca} ${vehicle2.modelo} té més valor en stock`)
}



