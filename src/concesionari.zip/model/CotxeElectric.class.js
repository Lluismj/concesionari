import Vehicle from './Vehicle.class.js'


class CotxeElectric extends Vehicle {

  constructor(marca, modelo, unitats, preu, autonomia) {

    super(marca, modelo, unitats, preu)

    this.autonomia = autonomia
  }


  // Sobreescrivim toString()
  toString() {
    return `${super.toString()} - Autonomia: ${this.autonomia} km`
  }

}

export default CotxeElectric